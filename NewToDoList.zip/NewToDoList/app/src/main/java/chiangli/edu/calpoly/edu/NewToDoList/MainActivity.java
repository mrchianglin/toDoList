package chiangli.edu.calpoly.edu.NewToDoList;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Layout;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private ArrayList<Entry> tasks;
    private ListView lv;
    private MyAdapter a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Log.d(TAG, "onCreate() called");


        tasks = (ArrayList<Entry>) getLastCustomNonConfigurationInstance();
        if (tasks == null) {
            tasks = new ArrayList<Entry>();
        }



        a = new MyAdapter(this, tasks);
        lv = (ListView) findViewById(R.id.lv);
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                confirmDialog(position);
                return true;

            }
        });
        lv.setAdapter(a);


        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        Button clickButton = (Button) findViewById(R.id.submit);
        clickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EditText header = (EditText) findViewById(R.id.header);
                String task = header.getText().toString();
                Log.d(TAG, "clickButton onClick called" + task);


                if (task.trim().length() > 0) {
                    header.setText("Task Name");

                    Entry entry = new Entry(task, false);
                    addView(entry, a);
                } else {
                    Toast.makeText(getApplicationContext(), "Enter a task name", Toast.LENGTH_SHORT).show();
                }
            }
        });

        EditText header = (EditText) findViewById(R.id.header);
        header.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                Log.d(TAG, "header onKey called");
                if (event.getAction() == KeyEvent.ACTION_DOWN
                        && event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    EditText header = (EditText) findViewById(R.id.header);
                    String task = header.getText().toString();

                    if (task.trim().length() > 0) {
                        TextView taskName = new TextView(getApplicationContext());
                        taskName.setText(task);
                        CheckBox cb = new CheckBox(getApplicationContext());
                        header.setText("Task Name");

                        Entry entry = new Entry(task, false);
                        addView(entry, a);
                    } else {
                        Toast.makeText(getApplicationContext(), "Enter a task name", Toast.LENGTH_SHORT).show();
                    }
                    return false;
                }
                return false;
            }
        });
    }

    private void addView(Entry e, MyAdapter a) {
        Log.d(TAG, "addView() " + e.checked + e.taskName);
        tasks.add(e);
        for (Entry task : tasks) {
            System.out.println(task.checked + task.taskName);
        }

        a.notifyDataSetChanged();
    }

    private void removeView(Entry e, MyAdapter a) {
        Log.d(TAG, "removeView() " + e.checked + e.taskName);
        tasks.remove(e);

        a.notifyDataSetChanged();
    }


    private class MyAdapter extends BaseAdapter {
        private ArrayList<Entry> tasks;
        private Context context;

        public MyAdapter(Context context, ArrayList<Entry> list) {
            this.context = context;
            this.tasks = list;
        }

        @Override
        public int getCount() {
            if (tasks == null) {
                return 0;
            }
            return tasks.size();
        }

        @Override
        public Object getItem(int position) {
            return tasks.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;

            if (view == null) {
                LayoutInflater inf = (LayoutInflater) LayoutInflater.from(parent.getContext());
                view = inf.inflate(R.layout.entry_item, parent, false);
            }

            final Entry e = tasks.get(position);
            TextView tv = (TextView) view.findViewById(R.id.tvTask);
            CheckBox cb = (CheckBox) view.findViewById(R.id.cbCheck);
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    e.checked = isChecked;
                }
            });
            tv.setText(e.taskName);
            cb.setChecked(e.checked);
            view.setLongClickable(true);
            return view;
        }
    }

    @Override
    public Object onRetainCustomNonConfigurationInstance() {
        return tasks;
    }

    public class Entry {
        String taskName;
        boolean checked;

        public Entry(String taskName, boolean checked) {
            this.taskName = taskName;
            this.checked = checked;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() called");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() called");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_share) {
            String taskString = "";
            Log.d(TAG, "onOptionsItemSelected; action_share");
            for (int i = 0; i < tasks.size(); i++) {
                String name = tasks.get(i).taskName;
                taskString += name + "\t ";
                if (tasks.get(i).checked) {
                    taskString += "1 \n";
                } else {
                    taskString += "0 \n";
                }
            }

            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, taskString);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void confirmDialog(int position) {
        final Entry e = tasks.get(position);
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Closing Activity")
                .setMessage("Are you sure you want to delete this tasks?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        removeView(e, a);
                    }

                })
                .setNegativeButton("No", null)
                .show();
    }
}
